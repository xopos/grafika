﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Grafika
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        Pen pisak = new Pen(Color.Black, 2);
        private Graphics g;
        private Point punkt;
        bool myszka = new Boolean();

        private void nowyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }

        private void otwórzToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = openFileDialog1.FileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Form1", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void zapiszToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (Nowy.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image.Save(Nowy.FileName, System.Drawing.Imaging.ImageFormat.Bmp);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Form1", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {

            punkt = e.Location;
            myszka = true;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (myszka == true)
            {
                if (punkt != null)
                {
                    if (pictureBox1.Image == null)
                    {
                        Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                        pictureBox1.Image = bmp;
                    }

                    using (Graphics g = Graphics.FromImage(pictureBox1.Image))

                    {

                        g.DrawLine(pisak, punkt, e.Location);


                    }

                    pictureBox1.Invalidate();

                    punkt = e.Location;

                }

            }

        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            myszka = false;
            punkt = Point.Empty;
        }
    }
}
